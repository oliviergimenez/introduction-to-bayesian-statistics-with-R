#' # Les méthodes MCMC
#' 
#' ## Introduction
#' 
#' ## Application du théorème de Bayes
#' 

library(tidyverse)

y <- 19 # nombre d'individus ayant survécu à l'hiver
n <- 57 # nombre d'individus suivis au début de l'hiver

num <- function(theta) dbinom(y, n, theta) * dbeta(theta, 1, 1)
num

den <- integrate(num, 0, 1)$value
den

## Approximation numérique de la distribution a posteriori de la survie hivernale.

# Crée une grille de valeurs possibles pour la probabilité de survie (entre 0 et 1)
grid <- seq(0, 1, 0.01)

# Calcule les valeurs de la densité a posteriori sur la grille
# num(grid) est la vraisemblance * prior, et den est la constante de normalisation
posterior <- data.frame(
  survival = grid, 
  ratio = num(grid) / den  # densité a posteriori normalisée
)

# Trace la courbe de la densité a posteriori
posterior %>%
  ggplot(aes(x = survival, y = ratio)) + 
  geom_line(size = 1.5) +
  labs(x = "Probabilité de survie", y = "Densité") +
  theme_minimal()

## Comparaison entre la postérieure exacte (couleur rouge brique) et 
## l’approximation numérique (couleur crème).
a <- 1; b <- 1
y <- 19; n <- 57
explicit_posterior <- dbeta(grid, y + a, n - y + b)
dfexpposterior <- data.frame(survival = grid, explicit_posterior = explicit_posterior)

library(wesanderson)
ggplot() + 
  geom_line(data = posterior, 
            aes(x = survival, y = ratio), 
            size = 1.5, 
            col = wesanderson::wes_palettes$Royal1[2],
            alpha = 0.5) + 
  geom_line(data = dfexpposterior, 
            aes(x = survival, y = explicit_posterior),
            size = 1.5, 
            col = wesanderson::wes_palettes$Royal1[3], 
            linetype = "dashed") +
  labs(x = "Probabilité de survie", y = "Densité") +
  theme_minimal()

#' ## Les algorithmes MCMC

# tirage de 1000 valeurs depuis la postérieure bêta(20,39)
sample_from_posterior <- rbeta(1000, 20, 39) 
# calcul de la moyenne par intégration Monte Carlo
mean(sample_from_posterior) 

20/(20+39) # espérance de la loi bêta(20,39)

quantile(sample_from_posterior, probs = c(2.5/100, 97.5/100))

temps <- matrix(c(0.8, 0.2, 0.9, 0.1), nrow = 2, byrow = T) # matrice de transition
etapes <- 20
for (i in 1:etapes){
  temps <- temps %*% temps # multiplication matricielle
}
round(temps, 2) # produit matriciel après 20 étapes

# 19 animaux retrouvés vivants sur 57 capturés, marqués et relâchés
y <- 19
n <- 57

# log-vraisemblance binomiale Bin(n = 57,p)
loglikelihood <- function(x, p){
  dbinom(x = x, size = n, prob = p, log = TRUE)
}

# densité du prior uniforme
logprior <- function(p){
  dunif(x = p, min = 0, max = 1, log = TRUE)
  # ou bien dbeta(x = p, shape1 = 0, shape2 = 1, log = TRUE)
}

# densité a posteriori (échelle logarithmique)
posterior <- function(x, p){
  loglikelihood(x, p) + logprior(p)
}

steps <- 100 # nombre d'étapes ou itérations de la chaîne
theta.post <- rep(NA, steps) # vecteur pour stocker les valeurs simulées
accept <- rep(NA, steps) # vecteur pour enregistrer les acceptations/rejets
set.seed(666) # pour la reproductibilité

inits <- 0.5 # valeur de départ choisie pour theta
theta.post[1] <- inits # on enregistre cette valeur comme première position de la chaîne
accept[1] <- 1 # la valeur initiale est acceptée par défaut

move <- function(x, away = 1){ 
  logitx <- log(x / (1 - x)) # transformation logit : transforme x de (0,1) vers (-∞,+∞)
  logit_candidate <- logitx + rnorm(1, 0, away) # on ajoute un bruit normal centré, de variance contrôlée par away
  candidate <- plogis(logit_candidate) # transformation réciproque (logit^-1) : retourne une valeur entre 0 et 1
  return(candidate) # retourne la valeur proposée
}

for (t in 2:steps){ # pour chaque itération, à partir de la 2e

  # Étape 2 : proposer une nouvelle valeur pour theta
  theta_star <- move(theta.post[t-1])  # valeur candidate tirée à partir de la valeur précédente
  
  # Étape 3 : calculer le rapport des densités postérieures (échelle log)
  pstar <- posterior(y, p = theta_star) # densité a posteriori à la valeur candidate
  pprev <- posterior(y, p = theta.post[t-1]) # densité a posteriori à la valeur courante
  logR <- pstar - pprev # différence sur l’échelle log
  R <- exp(logR) # on revient à l’échelle naturelle (rapport des densités)

  # Étape 4 : décider si on accepte ou rejette la proposition
  X <- runif(1, 0, 1) # tirage aléatoire entre 0 et 1 : la "roulette" d’acceptation
  if (X < R){ # si la proposition est plus plausible (ou pas trop pire)
    theta.post[t] <- theta_star # on accepte et on stocke la valeur candidate
    accept[t] <- 1 # on note que la proposition a été acceptée
  } else {
    theta.post[t] <- theta.post[t-1] # sinon on reste sur la valeur précédente
    accept[t] <- 0 # on note le refus
  }
}

head(theta.post)
tail(theta.post)

## Trace plot des valeurs simulées de la probabilité de survie theta au fil des itérations.
df <- data.frame(x = 1:steps, y = theta.post)

ggplot(df, aes(x = x, y = y)) +
  geom_line(size = 1.5, color = "steelblue") +
  labs(x = "Itérations", 
       y = expression("Valeurs simulées de la probabilité de survie " * theta)) +
  ylim(0.1, 0.6) +
  theme_minimal()

metropolis <- function(steps = 100, inits = 0.5, away = 1){
  
  theta.post <- rep(NA, steps) # on crée un vecteur pour stocker les échantillons
  theta.post[1] <- inits # on initialise avec la valeur de départ
  
  for (t in 2:steps){ # boucle sur les étapes (à partir de la 2ème)
    
    theta_star <- move(theta.post[t-1], away) # proposition d'une nouvelle valeur

    # on calcule le log-ratio de la densité a posteriori entre candidat et position courante
    logR <- posterior(y, theta_star) - 
            posterior(y, theta.post[t-1])
    R <- exp(logR) # passage à l'échelle normale (non log)
    
    X <- runif(1, 0, 1) # tirage d'un nombre aléatoire uniforme
    theta.post[t] <- ifelse(X < R, # si le tirage < probabilité d'acceptation...
                            theta_star, # ... on accepte la valeur proposée
                            theta.post[t-1]) # sinon on conserve la précédente
  }
  
  return(theta.post) # on retourne l’échantillon simulé
}

theta.post2 <- metropolis(steps = 100, inits = 0.2) # départ à 0.2

## Trace plot des valeurs simulées de la probabilité de survie theta
## au fil des itérations. Deux chaînes ont été lancées avec des valeurs 
## initiales différentes, 0.5 en bleu et 0.2 en jaune.
df2 <- data.frame(x = 1:steps, y = theta.post2)          # données formatées pour ggplot
ggplot() +
  geom_line(data = df, aes(x = x, y = y), size = 1.5, color = wesanderson::wes_palettes$Zissou1[1]) +
  geom_line(data = df2, aes(x = x, y = y), size = 1.5, color = wesanderson::wes_palettes$Zissou1[3]) +
  labs(x = "Itérations", 
       y = expression("Valeurs simulées de la probabilité de survie " * theta)) +
  ylim(0.1, 0.6)

## Trace plot des valeurs simulées de la probabilité de survie theta au fil des 1000 itérations.
steps <- 1000 # on augmente le nombre d'itérations
set.seed(666) # on garde la reproductibilité
theta.post <- metropolis(steps = steps, # on relance la fonction avec 5000 étapes
                         inits = 0.5) # valeur de départ : 0.5
df <- data.frame(x = 1:steps, y = theta.post) # on met en forme les résultats
ggplot(df, aes(x = x, y = y)) +
  geom_line(size = 1, color = wesanderson::wes_palettes$Zissou1[1]) + # courbe des valeurs simulées
  labs(x = "Itérations", 
       y = expression("Valeurs simulées de la probabilité de survie " * theta)) +
  ylim(0.1, 0.6) + # échelle fixe pour cohérence visuelle
  geom_hline(aes(yintercept = mean(theta.post), linetype = "moyenne a posteriori")) +  # moyenne de la chaîne
  scale_linetype_manual(name = "", values = c(2, 2)) # ligne pointillée pour la moyenne

#' ## Évaluer la convergence

## Trace plot pour une chaîne démarrant à 0.99. La zone ombrée illustre 
## une période de burn-in possible.
steps <- 1000
theta.post <- metropolis(steps = steps, inits = 0.99)
df <- data.frame(x = 1:steps, y = theta.post)
df %>%
  ggplot() +
  geom_line(aes(x = x, y = y), size = 1.2, color = wesanderson::wes_palettes$Zissou1[1]) + 
  labs(x = "itérations", 
       y = expression("Valeurs simulées de la probabilité de survie " * theta)) + 
  theme_light(base_size = 14) + 
  annotate("rect", xmin = 0, xmax = 100, ymin = 0.1, ymax = 1, alpha = .3) +
  scale_y_continuous(expand = c(0,0))

## Valeur de la statistique de Brooks-Gelman-Rubin (BGR) en fonction du 
## nombre d’itérations. Une valeur proche de 1 suggère la convergence.
set.seed(1234)
simul.bgr <- function(steps, inits){
  nb.replicates <- length(inits)
  theta.post <- matrix(NA, nrow = nb.replicates, ncol = steps)
  for (i in 1:nb.replicates){
    theta.post[i,1:steps] <- metropolis(steps = steps, inits = inits[i])
  }
  df <- data.frame(x = rep(1:steps, nb.replicates), 
                   y = c(t(theta.post)), 
                   chain = paste0("chaîne ", gl(nb.replicates, steps))) %>%
    filter(x > round(steps/2))
  num <- quantile(df$y, probs = c(0.2, 0.8))[2] - quantile(df$y, probs = c(0.2, 0.8))[1]
  den <- df %>%
    group_by(chain) %>%
    summarise(ci = quantile(y, probs = c(0.2, 0.8))) %>%
    mutate(diff = ci - lag(ci, default = ci[1])) %>%
    filter(diff != 0) %>%
    pull(diff) %>%
    mean()
  round(num / den, 3)
}
steps_seq <- seq(100, 1000, 50)
bgr <- sapply(steps_seq, function(s) simul.bgr(s, c(0.2, 0.8)))
df_bgr <- data.frame(itérations = steps_seq, BGR = bgr)
df_bgr %>%
  ggplot() +
  geom_line(aes(x = itérations, y = BGR), size = 1.2) +
  labs(x = "Itérations", y = "Statistique BGR")

#' ### Longueur de chaîne

## Trace plots pour différentes valeurs de l'écart-type de la proposition 
## (away). Un bon mixing est observé avec away = 1. La zone grise ombrée 
## correspond à un burn-in de 300 itérations.
n_steps <- 3000
set.seed(666)

# Générer les chaînes pour trois valeurs d'écart-type
d <- tibble(away = c(0.1, 1, 10)) %>% 
  mutate(accepted_traj = map(away, metropolis, steps = n_steps, inits = 0.1)) %>% 
  unnest(accepted_traj)

# Ajout de colonnes pour le faceting et l’itération
d <- d %>% 
  mutate(proposal_sd = str_c("Écart-type = ", away),
         iter = rep(1:n_steps, times = 3))

# Tracé avec zone de burn-in
ggplot(d, aes(x = iter, y = accepted_traj)) +
  # zone ombrée pour le burn-in
  geom_rect(data = d %>% distinct(proposal_sd), 
            inherit.aes = FALSE,
            aes(xmin = 0, xmax = 300, ymin = -Inf, ymax = Inf), 
            fill = "grey80", alpha = 0.4) +
  # trace plot
  geom_path(size = 0.25, color = "steelblue") +
  geom_point(size = 0.5, alpha = 0.5, color = "steelblue") +
  facet_wrap(~proposal_sd, ncol = 3) +
  labs(x = "Itérations", 
       y = expression("Valeurs simulées de la probabilité de survie " * theta)) + 
  theme_light(base_size = 14)

## Fonctions d'autocorrélation (ACF) pour différentes valeurs de l'écart-type 
## de la proposition. Une faible autocorrélation est un signe de bon mixing. 
## Un burn-in de 300 itérations est appliqué.
library(forecast)
plot1 <- ggAcf(d$accepted_traj[d$proposal_sd == "Écart-type = 0.1"][-c(1:300)]) + ggtitle("Écart-type = 0.1")
plot2 <- ggAcf(d$accepted_traj[d$proposal_sd == "Écart-type = 1"][-c(1:300)]) + ggtitle("Écart-type = 1")
plot3 <- ggAcf(d$accepted_traj[d$proposal_sd == "Écart-type = 10"][-c(1:300)]) + ggtitle("Écart-type = 10")
library(patchwork)
(plot1 + plot2 + plot3)

# Générer les chaînes pour trois valeurs d'écart-type
d <- tibble(away = c(0.1, 1, 10)) %>% 
     mutate(accepted_traj = map(away, 
					   metropolis, 
                                steps = n_steps, 
                                inits = 0.1)) %>% 
     unnest(accepted_traj) %>%
     mutate(proposal_sd = str_c("Écart-type = ", away),
            iter = rep(1:n_steps, times = 3))

# Calculer la taille effective d'échantillon
neff1 <- coda::effectiveSize(d$accepted_traj[d$proposal_sd=="Écart-type = 0.1"][-c(1:300)])
neff2 <- coda::effectiveSize(d$accepted_traj[d$proposal_sd=="Écart-type = 1"][-c(1:300)])
neff3 <- coda::effectiveSize(d$accepted_traj[d$proposal_sd=="Écart-type = 10"][-c(1:300)])
tibble("Écart-type" = c(0.1, 1, 10),
       "n.eff" = round(c(neff1, neff2, neff3)))

#' ### Et si vous avez des problèmes de convergence ?

#' ## En résumé
