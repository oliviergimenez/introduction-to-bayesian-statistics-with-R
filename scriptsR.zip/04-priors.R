#' # Les distributions a priori

#' ## Introduction

#' ## Le rôle du prior

#' ## Sensibilité au prior

library(tidyverse)

# Grille theta
x <- seq(0, 1, length.out = 500)

# Paramètres des priors et des tailles d’échantillon
priors <- tribble(
  ~a, ~b, ~Prior,
  1, 1, "Beta(1, 1)",
  5,   5,   "Beta(5, 5)",
  20,  1,   "Beta(20, 1)"
)

echantillons <- tribble(
  ~n, ~y,
  6, 2,
  57, 19
)

# Combinaison priors × tailles
df <- crossing(priors, echantillons) %>%
  mutate(
    post_a = a + y,
    post_b = b + n - y,
    Prior = factor(Prior, levels = c("Beta(1, 1)", "Beta(5, 5)", "Beta(20, 1)")),
    Echantillon = factor(paste0("n = ", n, ", y = ", y),
                     levels = c("n = 6, y = 2", "n = 57, y = 19"))) %>%
  rowwise() %>%
  mutate(plotdata = list(tibble(
    theta = x,
    Prior = dbeta(x, a, b),
    Posterior = dbeta(x, post_a, post_b)
  ) %>%
    pivot_longer(cols = c(Prior, Posterior), names_to = "Type", values_to = "Densité"))) %>%
  unnest(plotdata)

# Tracer
ggplot(df, aes(x = theta, y = Densité, color = Type)) +
  geom_line(size = 1.2) +
  facet_grid(rows = vars(Echantillon), cols = vars(Prior)) +
  scale_color_manual(values = c("Prior" = "red", "Posterior" = "black")) +
  labs(x = expression(theta), y = "Densité", color = NULL) +
  theme_minimal(base_size = 13) +
  theme(legend.position = "top",
        strip.text = element_text(size = 12))


#' ## Comment intégrer l'information a priori ?

#' ### Méta-analyse

df <- tibble::tibble(
  Prior = factor(rep(c("Beta(1,1)", "N(0.57, 0.075²)"), times = 2),
                 levels = c("Beta(1,1)", "N(0.57, 0.075²)")),
  Données = rep(c("7 ans", "3 ans"), each = 2),
  Moyenne = c(0.56, 0.56, 0.70, 0.60),
  IC_inf = c(0.51, 0.52, 0.47, 0.48),
  IC_sup = c(0.61, 0.61, 0.95, 0.72)
)

df <- df %>%
  mutate(x = paste0(Prior, "\n(", Données, ")"),
         couleur = ifelse(Données == "7 ans", "black", "darkred"))

ggplot(df, aes(x = x, y = Moyenne, color = Données)) +
  geom_point(size = 3) +
  geom_errorbar(aes(ymin = IC_inf, ymax = IC_sup), width = 0.15) +
  geom_hline(yintercept = 0.57, linetype = "dashed", color = "grey40") +
  scale_color_manual(values = c("7 ans" = "black", "3 ans" = "darkred")) +
  labs(x = NULL, y = "Probabilité de survie", color = NULL) +
  theme_minimal(base_size = 13) +
  theme(axis.text.x = element_text(size = 11),
        legend.position = "top") # remplacer top par none si on ne veut pas la légende

# # load nimbleEcology and a few other packages
# library(nimbleEcology)
# library(tidyverse)
# library(MCMCvis)
# 
# #---------- toutes les données
# y <- matrix(scan("dat/dipper.dat"), ncol = 7, byrow = T)
# 
# # get occasions of first capture
# first <- apply(y, 1, function(x) min(which(x !=0)))
# 
# # get rid of individuals for which first detection = last capture
# y <- y[ first != ncol(y), ]
# 
# # re-calculate occasions of first capture
# first <- apply(y, 1, function(x) min(which(x !=0)))
# 
# # NIMBLE code
# phip.vague <- nimbleCode({
#   phi ~ dunif(0, 1) # survival prior
#   p ~ dunif(0, 1)   # detection prior
#   # likelihood
#   for (i in 1:N){
#     y[i, first[i]:T] ~ dCJS_ss(probSurvive = phi,
#                                probCapture = p,
#                                len = T - first[i] + 1)
#   }
# })
# phip.informative <- nimbleCode({
#   phi ~ dnorm(0.57, sd = 0.075) # survival prior
#   p ~ dunif(0, 1)   # detection prior
#   # likelihood
#   for (i in 1:N){
#     y[i, first[i]:T] ~ dCJS_ss(probSurvive = phi,
#                                probCapture = p,
#                                len = T - first[i] + 1)
#   }
# })
# # constants
# my.constants <- list(N = nrow(y),
#                      T = ncol(y),
#                      first = first)
# # data
# my.data <- list(y = y) # format is 0 for non-detected and 1 for detected
# 
# # initial values; we use the marginalized likelihood, so no latent states
# # in it, therefore no need for initial values for the latent states
# initial.values <- function() list(phi = runif(1,0,1),
#                                   p = runif(1,0,1))
# # parameters to monitor
# parameters.to.save <- c("phi", "p")
# # MCMC details
# n.iter <- 10000
# n.burnin <- 2500
# n.chains <- 2
# 
# # run NIMBLE
# mcmc.vague <- nimbleMCMC(code = phip.vague,
#                         constants = my.constants,
#                         data = my.data,
#                         inits = initial.values,
#                         monitors = parameters.to.save,
#                         niter = n.iter,
#                         nburnin = n.burnin,
#                         nchains = n.chains)
# 
# # run NIMBLE
# mcmc.informative <- nimbleMCMC(code = phip.informative,
#                         constants = my.constants,
#                         data = my.data,
#                         inits = initial.values,
#                         monitors = parameters.to.save,
#                         niter = n.iter,
#                         nburnin = n.burnin,
#                         nchains = n.chains)
# 
# # numerical summaries
# MCMCsummary(mcmc.vague, round = 2)
# MCMCsummary(mcmc.informative, round = 2)
# 
# #---------- seulement les trois premières années de données
# 
# y <- matrix(scan("dat/dipper.dat"), ncol = 7, byrow = T)
# # on prend les trois premieres années
# y <- y[,1:3]
# # on supprime les lignes de 0 qui correspondent à des oiseaux jamais capturés
# y <- y[apply(y,1,sum)!=0,]
# 
# # get occasions of first capture
# first <- apply(y, 1, function(x) min(which(x !=0)))
# 
# # get rid of individuals for which first detection = last capture
# y <- y[ first != ncol(y), ]
# 
# # re-calculate occasions of first capture
# first <- apply(y, 1, function(x) min(which(x !=0)))
# 
# # constants
# my.constants <- list(N = nrow(y),
#                      T = ncol(y),
#                      first = first)
# # data
# my.data <- list(y = y) # format is 0 for non-detected and 1 for detected
# 
# # run NIMBLE
# mcmc.vague <- nimbleMCMC(code = phip.vague,
#                         constants = my.constants,
#                         data = my.data,
#                         inits = initial.values,
#                         monitors = parameters.to.save,
#                         niter = n.iter,
#                         nburnin = n.burnin,
#                         nchains = n.chains)
# 
# # run NIMBLE
# mcmc.informative <- nimbleMCMC(code = phip.informative,
#                         constants = my.constants,
#                         data = my.data,
#                         inits = initial.values,
#                         monitors = parameters.to.save,
#                         niter = n.iter,
#                         nburnin = n.burnin,
#                         nchains = n.chains)
# 
# # numerical summaries
# MCMCsummary(mcmc.vague, round = 2)
# MCMCsummary(mcmc.informative, round = 2)


#' ### Méthode du moment-matching

# paramètres de moyenne et d'écart-type souhaités pour la distribution bêta
mu <- 0.57 # moyenne de la probabilité
sigma <- 0.075 # écart-type sur cette probabilité
# formules inverses pour obtenir les paramètres a et b d'une distribution bêta
a <- ((1 - mu) / (sigma^2) - 1 / mu) * mu^2
b <- a * (1 / mu - 1)
# affichage des valeurs de a et b arrondies
c(a = round(a, 1), b = round(b, 1))


# on génère 10000 valeurs tirées d'une loi Bêta avec les paramètres a = 24.3 et b = 18.3
ech_prior <- rbeta(n = 10000, shape1 = 24.3, shape2 = 18.3)
# on calcule la moyenne empirique des tirages (doit approcher 0.57)
mean(ech_prior)
# on calcule l'écart-type empirique des tirages (doit approcher 0.075)
sd(ech_prior)


# borne inférieure et supérieure données par l’expert·e
a <- -0.15
b <-  0.25

# niveau de confiance exprimé
level <- 0.80
alpha <- 1 - level

# valeur z correspondant à un intervalle de crédibilité à 80 %
z <- qnorm(1 - alpha / 2)  # ≈ 1.2816

# moyenne = centre de l’intervalle
mu <- (a + b) / 2

# écart-type déduit de la largeur de l’intervalle
sigma <- (b - a) / (2 * z)

mu
sigma


mu    <- 0.05
sigma <- 0.1560608
pnorm(c(-0.15, 0.25), mean = mu, sd = sigma)
#> 0.10 0.90    # Ok : 10 % à gauche, 90 % à droite → 80 % au centre

# Paramètres du prior
mu <- 0.05
sigma <- 0.156
a <- -0.15
b <-  0.25

# Courbe de densité
x <- seq(mu - 4*sigma, mu + 4*sigma, length.out = 1000)
y <- dnorm(x, mean = mu, sd = sigma)
df <- data.frame(x = x, y = y)

# Sous-ensemble pour l’aire ombrée
highlight <- subset(df, x >= a & x <= b)

# Tracé
ggplot(df, aes(x, y)) +
  geom_line(color = "black", size = 1.2) +
  geom_area(data = highlight, fill = "steelblue", alpha = 0.4) +
  geom_vline(xintercept = c(a, b), linetype = "dotted", color = "grey40") +
  geom_vline(xintercept = mu, linetype = "dashed", color = "black") +
  annotate("text", x = mu, y = max(y) * 0.6, label = "80 % de masse", size = 5, fontface = "bold") +
  annotate("text", x = a, y = 0.01, label = "-0.15", hjust = 1.2, size = 4) +
  annotate("text", x = b, y = 0.01, label = "0.25", hjust = -0.2, size = 4) +
  annotate("text", x = mu + 0.25, y = max(y) * 0.7,
           label = "mu == 0.05~et~sigma == 0.156",
           parse = TRUE, hjust = 0, size = 5) +
  labs(
    title = "",
    x = expression(theta),
    y = "Densité"
  ) +
  theme_minimal(base_size = 14)

#' ## Attention aux priors dits non-informatifs

set.seed(1)
logit_prior <- rnorm(n = 1000, mean = 0, sd = 10)
prior <- plogis(logit_prior)

logit_prior2 <- rnorm(n = 1000, mean = 0, sd = 1.5)
prior2 <- plogis(logit_prior2)

df <- data.frame(
  prob = c(prior, prior2),
  prior_type = factor(rep(c("N(0, 10²)", "N(0, 1.5²)"), each = 1000),
                      levels = c("N(0, 10²)", "N(0, 1.5²)"))  # ordre explicite
)

ggplot(df, aes(x = prob, fill = prior_type)) +
  geom_histogram(bins = 30, alpha = 0.8, color = "black") +
  facet_wrap(~ prior_type) +
  scale_fill_manual(values = c("steelblue", "tomato")) +
  xlab("") +
  ylab("Fréquence") +
  ggtitle("") +
  theme_minimal() +
  theme(legend.position = "none")


#' ## En résumé
