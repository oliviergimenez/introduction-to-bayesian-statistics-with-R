#' # Modèles linéaires généralisés, et généralisés mixtes

#' ## Introduction 

#' ## Modèles linéaires généralisés (GLMs)

library(tidyverse)
library(patchwork)

# Fonctions
logit <- function(p) log(p / (1 - p))
inv_logit <- function(x) 1 / (1 + exp(-x))

# Données pour logit
p_vals <- seq(0.001, 0.999, length.out = 500)
df_logit <- data.frame(
  p = p_vals,
  logit_p = logit(p_vals)
)

# Données pour logit inverse
x_vals <- seq(-6, 6, length.out = 500)
df_invlogit <- data.frame(
  x = x_vals,
  p = inv_logit(x_vals)
)

# Graphique 1 : fonction logit
plot_logit <- ggplot(df_logit, aes(x = p, y = logit_p)) +
  geom_line(color = "blue", size = 1.2) +
  labs(
    title = "Fonction logit",
    x = "Probabilité (p)",
    y = "logit(p)"
  ) +
  theme_minimal()

# Graphique 2 : fonction logistique inverse
plot_invlogit <- ggplot(df_invlogit, aes(x = x, y = p)) +
  geom_line(color = "darkgreen", size = 1.2) +
  geom_hline(yintercept = c(0, 1), linetype = "dotted", color = "gray40") +
  geom_vline(xintercept = 0, linetype = "dashed", color = "gray40") +
  annotate("text", x = 0, y = 0.55, label = "x = 0, p = 0.5", hjust = 0.5, vjust = 0, size = 4) +
  labs(
    title = "Fonction logit inverse",
    x = "Valeur linéaire (x)",
    y = "Probabilité"
  ) +
  theme_minimal()

# Combiner les deux
plot_logit + plot_invlogit

# Nombre total de ragondins suivis, survivants
n <- 57
y <- 19

# Créer les données individuelles (0 = mort, 1 = vivant)
z <- c(rep(1, y), rep(0, n - y))

# Ajouter une covariable continue (ex : masse)
set.seed(123)
masse <- rnorm(n, mean = 5, sd = 1)  # masse simulée en kg

df_bern <- data.frame(survie = z, masse = masse)

# Charge package
library(brms)

# Ajustement de la régression linéaire
fit_lm <- brm(survie ~ masse, 
              data = df_bern, 
              family = gaussian(),
              seed = 123, 
              chains = 2, 
              iter = 2000,
              refresh = 0)

# Ajustement de la régression logistique
fit_logit <- brm(survie ~ masse, 
                 data = df_bern, 
                 family = bernoulli(),
                 seed = 123, 
                 iter = 2000, 
                 chains = 2, 
                 refresh = 0)


## Illustration de la règle du 4 de Gelman. Ici, on approxime l’effet de la 
## masse du ragondin sur la probabilité de survie (la courbe logistique en 
## noir) autour du point d’inflexion par une droite dont la pente est donnée 
## par le coefficient estimé divisé par 4 (la droite en tirets rouge).

# Extraire les coefficients postérieurs moyens
post <- fixef(fit_logit)
intercept <- post["Intercept", "Estimate"]
slope <- post["masse", "Estimate"]

# Règle du 4 de Gelman
approx_slope <- slope / 4
p0 <- plogis(intercept)  # probabilité au point d'inflexion (x = 0 si centré)

# Séquence de masse centrée pour le graphique
masse_seq <- seq(0, 15, length.out = 100)
proba <- plogis(intercept + slope * masse_seq)

# Créer le graphique
df_pred <- data.frame(masse = masse_seq, proba = proba)

ggplot(df_pred, aes(x = masse, y = proba)) +
  geom_line(linewidth = 1.2) +
  geom_abline(intercept = p0, slope = approx_slope, color = "red", linetype = "dashed") +
  labs(x = "Masse (kg)", y = "Probabilité de survie") +
  theme_minimal()

## Comparaison entre une régression linéaire et une régression logistique 
## ajustées sur des données binaires. La régression linéaire (en bleu) produit 
## des prédictions plus grandes que 1 (embêtant pour une probabilité de survie), 
## tandis que la régression logistique (en rouge) garantit une estimation de 
## probabilité valide.

# Créer une séquence de masse pour prédiction
newdata <- data.frame(masse = seq(0, 25, length.out = 100))

# Prédictions des deux modèles
pred_lm <- fitted(fit_lm, newdata = newdata, summary = TRUE)
pred_logit <- fitted(fit_logit, newdata = newdata, summary = TRUE)

df_lm <- data.frame(masse = newdata$masse,
                    estimate = pred_lm[,'Estimate'],
                    model = "Régression linéaire (normale)")

df_logit <- data.frame(masse = newdata$masse,
                       estimate = pred_logit[,'Estimate'],
                       model = "Régression logistique (bernoulli)")

df_plot <- bind_rows(df_lm, df_logit)

# Tracer les deux courbes
ggplot() +
  geom_line(data = df_plot, aes(x = masse, y = estimate, color = model),
            size = 1.2) +
  scale_color_manual(values = c("Régression linéaire (normale)" = "blue",
                                "Régression logistique (bernoulli)" = "red")) +
  labs(title = "",
       x = "Masse (kg)",
       y = "Probabilité estimée de survie") +
  coord_cartesian(ylim = c(-0.2, 1.2)) +
  theme_minimal() +
  theme(legend.title = element_blank())

#' ## Modèles linéaires généralisés mixtes (GLMMs)

#' ### Introduction

#' ### Exemple

## Schéma des données sur les ragondins selon un protocole d’échantillonnage 
## avec 10 points dans 10 transects. L'aire d'étude est en noir. En haut on a 
## le nombre de ragondins, et en bas la température.

set.seed(123)

# Définir l'aire d’étude patatoïde
study_area <- tibble(
  angle = seq(0, 2 * pi, length.out = 100)
) |>
  mutate(
    radius = 40 + 5 * sin(3 * angle) + 3 * cos(5 * angle),
    X = radius * cos(angle) + 50,
    Y = radius * sin(angle) + 50
  )

# Transects réguliers horizontaux
n_transects <- 10
n_segments <- 10
transect_Y <- seq(30, 70, length.out = n_transects)
segment_X <- seq(30, 70, length.out = n_segments)

transect_grid <- expand.grid(
  Y = transect_Y,
  X = segment_X
) |>
  mutate(Transect = factor(Y),
         Segment = X)

# Garder les points dans l'aire d'étude
inside <- function(x, y, polygon_df) {
  sp::point.in.polygon(x, y, polygon_df$X, polygon_df$Y) > 0
}

transect_inside <- transect_grid |>
  filter(inside(X, Y, study_area)) |>
  mutate(
    Temperature = 18 + 0.04 * X - 0.02 * Y,
    Lambda = exp(0.2 * Temperature),
    Ragondins = rpois(n(), Lambda)
  )

# Panel 1 : Ragondins
p1 <- ggplot() +
  geom_polygon(data = study_area, aes(x = X, y = Y),
               fill = NA, color = "black") +
  geom_path(data = transect_inside,
            aes(x = X, y = Y, group = Transect),
            color = "grey50") +
  geom_point(data = transect_inside,
             aes(x = X, y = Y, color = Ragondins), size = 2) +
  scale_color_viridis_c(option = "plasma") +
  labs(title = "Nombre de ragondins",
       x = "X (m)", y = "Y (m)", color = "Ragondins") +
  coord_fixed() +
  theme_minimal()

# Panel 2 : Température
p2 <- ggplot() +
  geom_polygon(data = study_area, aes(x = X, y = Y),
               fill = NA, color = "black") +
  geom_path(data = transect_inside,
            aes(x = X, y = Y, group = Transect),
            color = "grey50") +
  geom_point(data = transect_inside,
             aes(x = X, y = Y, color = Temperature), size = 2) +
  scale_color_viridis_c(option = "viridis") +
  labs(title = "Température",
       x = "X (m)", y = "Y (m)", color = "Température (°C)") +
  coord_fixed() +
  theme_minimal()

# Assemblage vertical
p1 / p2

set.seed(123) # pour la reproductibilité
transects <- 10 # nombre total de transects
nb_points <- c(10, 10, 10, 3, 2, 10, 10, 3, 10, 10) # nombre de points par transect
data <- NULL # objet qui stockera les données simulées
for (tr in 1:transects){
  ref <- rnorm(1, 0, .3) # effet aléatoire du transect (N(0,0.3²))
  # température simulée le long du transect :
  # point de départ aléatoire entre 18 et 22 °C puis légère pente par segment
  t <- runif(1, 18, 22) + runif(1, -0.2, 0.2) * 1:10
  # intensité attendue (échelle log) : relation linéaire avec la température
  ans <- exp(ref + 0.2 * t)
  # comptage Poisson de ragondins pour chaque point
  an <- rpois(nb_points[tr], ans)
  # empile les 10 points du transect courant
  data <- rbind(data, cbind(rep(tr, nb_points[tr]), t[1:nb_points[tr]], an))
}
# on met tout dans un data.frame
sim_simple <- data.frame(
  Transect    = data[, 1],
  Temperature = data[, 2],
  Ragondins    = data[, 3]
)
head(sim_simple)

## Relation entre le nombre de ragondins et la température par transect, avec 
## plusieurs points de comptage (10 pour tous, sauf les transects 4, 5 et 8 
## pour lesquels on a 3, 2 et 3 points) par transect.
sim_simple %>%
  ggplot(aes(x = Temperature, y = Ragondins, colour = factor(Transect))) +
  geom_line() +
  geom_point(size = 1) +
  labs(colour = "Transect") +
  theme_minimal()

#' ### L'approche GLM

library(brms)

# on n'oublie pas de centrer-réduire la covariable température
sim_simple$Temp <- scale(sim_simple$Temperature)

# modèle avec complete pooling / regroupement complet
fit_complete <- brm(Ragondins ~ Temp,
                    data = sim_simple, # données simulées
                    family = poisson("log"), # distribution de Poisson, lien log
                    chains = 2, # nombre de chaînes MCMC
                    iter = 5000, # nombre total d’itérations par chaîne
                    warmup = 1000, # nombre d’itérations de burn-in
                    seed = 666, # graine pour reproductibilité
                    refresh = 0)

summary(fit_complete)

## Vérification de l'adéquation du modèle avec complete pooling ou regroupement 
## complet. L’axe des abscisses représente les valeurs possibles de la variable 
## réponse simulée ou observée. L’axe des ordonnées indique leur densité estimée. 
## Les distributions simulées (en bleu) sont comparées aux données observées (en 
## noir). Le mauvais recouvrement indique une mauvaise adéquation du modèle aux données.
brms::pp_check(fit_complete)

# Modèle avec no pooling / pas de regroupement (effet fixe transect)
fit_nopool <- brm(Ragondins ~ Temp + as.factor(Transect),
                    data = sim_simple, # données simulées
                    family = poisson("log"), # distribution de Poisson, lien log
                    chains = 2, # nombre de chaînes MCMC
                    iter = 5000, # nombre total d’itérations par chaîne
                    warmup = 1000, # nombre d’itérations de burn-in
                    seed = 666, # graine pour reproductibilité
                    refresh = 0)

summary(fit_nopool)

# extraire l'intercept (référence = Transect 1)
beta0 <- fixef(fit_nopool)["Intercept", "Estimate"]

# tous les coefficients du modèle
coefs <- fixef(fit_nopool)

# effets associés aux autres transects
coefs_transects <- coefs[grep("as.factor", rownames(coefs)), "Estimate"]

# calcul des intercepts par transect
intercepts_log <- c(
  Transect1 = beta0,
  beta0 + coefs_transects
)

# calcul des nombres moyens attendus de ragondins sur l’échelle d’origine
nombres <- exp(intercepts_log)

# le tableau qui résume
df_intercepts <- data.frame(
  Transect = names(intercepts_log),
  Intercept_log = round(intercepts_log, 2),
  Nombre = round(nombres, 2)
)

# affichage
df_intercepts

## Vérification de l'adéquation du modèle avec no pooling ou pas de regroupement. 
## L’axe des abscisses représente les valeurs possibles de la variable réponse 
## simulée ou observée. L’axe des ordonnées indique leur densité estimée. Les 
## distributions simulées (en bleu) sont comparées aux données observées (en noir).
brms::pp_check(fit_nopool)

## Comparaison entre les modèles complete pooling (noir) et no pooling (rouge) 
## pour prédire le nombre de ragondins en fonction de la température, par transect. 
## Le modèle no pooling ajuste une courbe indépendante pour chaque transect, tandis 
## que le complete pooling suppose une relation commune.

grid <- sim_simple %>%
  select(Temp, Transect)

# Prédictions pour chaque modèle
grid$y_complete <- fitted(fit_complete, newdata = grid)[, "Estimate"]
grid$y_nopool   <- fitted(fit_nopool, newdata = grid)[, "Estimate"]

# Tracé des trois modèles côte à côte en facettes
sim_simple$fTransect <- factor(sim_simple$Transect)
grid$Transect <- factor(grid$Transect)

# Créer un data.frame long pour pouvoir mapper color = model
grid_long <- grid %>%
  select(Temp, Transect, y_complete, y_nopool) %>%
  pivot_longer(cols = c(y_complete, y_nopool),
               names_to = "Model", values_to = "Prediction") %>%
  mutate(Model = recode(Model,
                        y_complete = "Complete pooling",
                        y_nopool   = "No pooling"))

# Tracé
ggplot(sim_simple, aes(x = Temp, y = Ragondins)) +
  geom_point(alpha = 0.6) +
  geom_line(data = grid_long, aes(y = Prediction, color = Model), size = 0.8) +
  facet_wrap(~Transect, ncol = 5, scales = "free") +
  labs(title = "",
       x = "Température (°C)",
       y = "Nombre de ragondins",
       color = "Modèle") +
  scale_color_manual(values = c("No pooling" = "red", "Complete pooling" = "black")) +
  theme_minimal()


#' ### L'approche GLMM

#' #### Ajustement du modèle avec `brms`

# modèle avec partial pooling (effet aléatoire transect)
fit_partial <- brm(Ragondins ~ Temp + (1 | Transect),
                    data = sim_simple, # données simulées
                    family = poisson("log"),           # distribution de Poisson, lien log
                    chains = 2,                         # nombre de chaînes MCMC
                    iter = 5000,                        # nombre total d’itérations par chaîne
                    warmup = 1000,                      # nombre d’itérations de burn-in
                    seed = 666,                          # graine pour reproductibilité
                    refresh = 0)

summary(fit_partial)

## Vérification de la convergence des chaînes MCMC pour le modèle avec partial pooling. 
## Dans les histogrammes (colonne de gauche), l’axe des abscisses représente les valeurs 
## possibles du paramètre estimé (intercept, pente ou écart-type) et l’axe des ordonnées 
## correspond à leur fréquence dans l’échantillon a posteriori. Dans les trace plots 
## (colonne de droite), l’axe des abscisses indique le numéro d’itération du MCMC, 
## tandis que l’axe des ordonnées représente la valeur simulée du paramètre à chaque 
## itération.
plot(fit_partial)

## Comparaison entre les modèles complete pooling (noir), no pooling (rouge) et 
## partial pooling (bleu) pour prédire le nombre de ragondins en fonction de la 
## température, par transect. Le modèle no pooling ajuste une courbe indépendante 
## pour chaque transect, le complete pooling suppose une relation commune, tandis 
## que le partial pooling fournit un compromis grâce à l'effet aléatoire transect.

grid <- sim_simple %>%
  select(Temp, Transect)

# prédictions pour chaque modèle
grid$y_complete <- fitted(fit_complete, newdata = grid)[, "Estimate"]
grid$y_nopool   <- fitted(fit_nopool, newdata = grid)[, "Estimate"]
grid$y_partial  <- fitted(fit_partial, newdata = grid)[, "Estimate"]

# tracé des trois modèles côte à côte en facettes
sim_simple$fTransect <- factor(sim_simple$Transect)
grid$Transect <- factor(grid$Transect)

# créer un data.frame long pour pouvoir mapper color = model
grid_long <- grid %>%
  select(Temp, Transect, y_complete, y_nopool, y_partial) %>%
  pivot_longer(cols = c(y_complete, y_nopool, y_partial),
               names_to = "Model", values_to = "Prediction") %>%
  mutate(Model = recode(Model,
                        y_complete = "Complete pooling",
                        y_nopool   = "No pooling",
                        y_partial = "Partial pooling"))

# figure
ggplot(sim_simple, aes(x = Temp, y = Ragondins)) +
  geom_point(alpha = 0.6) +
  geom_line(data = grid_long, aes(y = Prediction, color = Model), size = 0.8) +
  facet_wrap(~Transect, ncol = 5, scales = "free") +
  labs(title = "",
       x = "Température (°C)",
       y = "Nombre de ragondins",
       color = "Modèle") +
  scale_color_manual(values = c("No pooling" = "red", "Complete pooling" = "black", "Partial pooling" = "blue")) +
  theme_minimal()

## Vérification de l'adéquation du modèle avec partial pooling ou regroupement 
## partiel. L’axe des abscisses représente les valeurs possibles de la variable 
## réponse simulée ou observée. L’axe des ordonnées indique leur densité estimée. 
## Les distributions simulées (en bleu) sont comparées aux données observées 
## (en noir).
brms::pp_check(fit_partial)

# on récupère les valeurs simulées dans les distributions a posteriori des paramètres
post <- as_draws_matrix(fit_partial)
sbzero <- post[, "b_Intercept"]
sbun <- post[, "b_Temp"]

# on récupère moyenne et écart-type de la température
mu <- attr(scale(sim_simple$Temperature), "scaled:center")
sg <- attr(scale(sim_simple$Temperature), "scaled:scale")

# on convertit les coefficients standardisés
bun   <- sbun / sg # beta1 réel
bzero <- sbzero - sbun * mu / sg # beta0 réel

## Distribution a posteriori de l'intercept moyen (échelle réelle). La ligne 
## rouge indique la vraie valeur (0).
tibble(b0 = bzero) %>%
  ggplot(aes(x = b0)) +
  geom_histogram(color = "white", fill = "skyblue", bins = 30) +
  geom_vline(xintercept = 0, color = "red", linewidth = 1.2) +
  labs(
    x = expression(beta[0]),
    y = "Fréquence"
  ) +
  theme_minimal()

## Distribution a posteriori de l'effet de la température (échelle réelle). 
## La ligne rouge indique la vraie valeur (0.2).
tibble(b1 = bun) %>%
  ggplot(aes(x = b1)) +
  geom_histogram(color = "white", fill = "skyblue", bins = 30) +
  geom_vline(xintercept = 0.2, color = "red", linewidth = 1.2) +
  labs(
    x = expression(beta[1]),
    y = "Fréquence"
  ) +
  theme_minimal()

# modèle avec partial pooling (effet aléatoire transect)
fit_partial2 <- brm(Ragondins ~ 1 + (1 | Transect),
                    data = sim_simple, # données simulées
                    family = poisson("log"), # distribution de Poisson, lien log
                    chains = 2, # nombre de chaînes MCMC
                    iter = 5000, # nombre total d’itérations par chaîne
                    warmup = 1000, # nombre d’itérations de burn-in
                    seed = 666, # graine pour reproductibilité
                    refresh = 0)

waic1 <- waic(fit_partial)
waic2 <- waic(fit_partial2)
tibble(
  Modèle = c("Avec température", "Sans température"),
  WAIC = c(waic1$estimates["waic", "Estimate"],
           waic2$estimates["waic", "Estimate"])
)

#' #### Ajustement du modèle avec `NIMBLE`

library(nimble)

model <- nimbleCode({
  for (i in 1:n){
    count[i] ~ dpois(theta[i]) # loi de Poisson
    log(theta[i]) <- intercept[transect[i]] + # intercept aléatoire par transect
                       beta1 * x[i] # effet linéaire de la température
  }
  for (j in 1:nbtransects){
    intercept[j] ~ dnorm(beta0, sd = sigma) # intercepts ~ N(beta0, sigma)
  }
  beta0 ~ dnorm(0, sd = 1.5) # prior sur la moyenne des intercepts
  sigma ~ dexp(1) # prior non informatif sur l'écart-type
  beta1 ~ dnorm(0, sd = 1.5) # prior sur le coef linéaire
})

my.constants <- list(
  n = nrow(sim_simple), # nombre d'observations
  nbtransects = transects # nombre de transects
)
my.data <- list(
  x = as.vector(sim_simple$Temp), # covariable standardisée
  count = sim_simple$Ragondins, # comptages
  transect = as.numeric(sim_simple$Transect) # identifiant du transect (effet aléatoire)
)

init1 <- list(
  intercept = rnorm(transects),
  beta1 = rnorm(1),
  beta0 = rnorm(1),
  sigma = rexp(1)
)

init2 <- list(
  intercept = rnorm(transects),
  beta1 = rnorm(1),
  beta0 = rnorm(1),
  sigma = rexp(1)
)

initial.values <- list(init1, init2)

parameters.to.save <- c("beta1", "beta0", "sigma")
n.iter <- 5000 # nb itérations totales
n.burnin <- 1000 # nb itérations burn-in
n.chains <- 2 # nombre de chaînes

mcmc.output <- nimbleMCMC(
  code = model,
  data = my.data,
  constants = my.constants,
  inits = initial.values,
  monitors = parameters.to.save,
  niter = n.iter,
  nburnin = n.burnin,
  nchains = n.chains,
  progressBar = FALSE)

library(MCMCvis)

MCMCsummary(object = mcmc.output, round = 2)

# on concatène des 2 chaînes
samples <- rbind(mcmc.output$chain1, mcmc.output$chain2)  

# on récupère les valuers simulées dans les distributions a posteriori des paramètres
sbzero <- samples[, 'beta0'] # beta0 standardisé
sbun   <- samples[, 'beta1'] # beta1 standardisé

# on récupère moyenne et écart-type de la température
mu <- attr(scale(sim_simple$Temperature), "scaled:center")
sg <- attr(scale(sim_simple$Temperature), "scaled:scale")

# on convertit les coefficients standardisés
bun   <- sbun / sg # beta1 réel
bzero <- sbzero - sbun * mu / sg # beta0 réel

## Distribution a posteriori de l'intercept moyen (échelle réelle). La ligne 
## rouge indique la vraie valeur (0).
tibble(b0 = bzero) %>%
  ggplot(aes(x = b0)) +
  geom_histogram(color = "white", fill = "skyblue", bins = 30) +
  geom_vline(xintercept = 0, color = "red", linewidth = 1.2) +
  labs(
    x = expression(beta[0]),
    y = "Fréquence"
  ) +
  theme_minimal()

## Distribution a posteriori de l'effet de la température (échelle réelle). 
## La ligne rouge indique la vraie valeur (0.2).
tibble(b1 = bun) %>%
  ggplot(aes(x = b1)) +
  geom_histogram(color = "white", fill = "skyblue", bins = 30) +
  geom_vline(xintercept = 0.2, color = "red", linewidth = 1.2) +
  labs(
    x = expression(beta[1]),
    y = "Fréquence"
  ) +
  theme_minimal()

# code du modèle sans température
model.null <- nimbleCode({
  for (i in 1:n){
    count[i] ~ dpois(theta[i])
    log(theta[i]) <- intercept[transect[i]]
  }
  for (j in 1:nbtransects){
    intercept[j] ~ dnorm(beta0, sd = sigma)
  }
  beta0 ~ dnorm(0, sd = 1.5)
  sigma ~ dexp(1)
})

# exécution du modèle nul
parameters.null <- c("beta0", "sigma")

mcmc.null <- nimbleMCMC(
  code = model.null,
  data = my.data,
  constants = my.constants,
  inits = list(beta0 = 0, sigma = 1, intercept = rnorm(transects)),
  monitors = parameters.null,
  niter = n.iter,
  nburnin = n.burnin,
  nchains = n.chains,
  progressBar = FALSE,
  WAIC = TRUE
)

model <- nimbleCode({
  for (i in 1:n){
    count[i] ~ dpois(theta[i]) # loi de Poisson
    log(theta[i]) <- intercept[transect[i]] + # intercept aléatoire par transect
                       beta1 * x[i] # effet linéaire de la température
  }
  for (j in 1:nbtransects){
    intercept[j] ~ dnorm(beta0, sd = sigma) # intercepts ~ N(beta0, sigma)
  }
  beta0 ~ dnorm(0, sd = 1.5) # prior sur la moyenne des intercepts
  sigma ~ dexp(1) # prior non informatif sur l'écart-type
  beta1 ~ dnorm(0, sd = 1.5) # prior sur le coef linéaire
})

my.constants <- list(
  n = nrow(sim_simple), # nombre d'observations
  nbtransects = transects # nombre de transects
)
my.data <- list(
  x = as.vector(sim_simple$Temp), # covariable standardisée
  count = sim_simple$Ragondins, # comptages
  transect = as.numeric(sim_simple$Transect) # identifiant du transect (effet aléatoire)
)

init1 <- list(
  intercept = rnorm(transects),
  beta1 = rnorm(1),
  beta0 = rnorm(1),
  sigma = rexp(1)
)

init2 <- list(
  intercept = rnorm(transects),
  beta1 = rnorm(1),
  beta0 = rnorm(1),
  sigma = rexp(1)
)

initial.values <- list(init1, init2)

parameters.to.save <- c("beta1", "beta0", "sigma")

mcmc.output <- nimbleMCMC(
  code = model,
  data = my.data,
  constants = my.constants,
  inits = initial.values,
  monitors = parameters.to.save,
  niter = n.iter,
  nburnin = n.burnin,
  nchains = n.chains,
  progressBar = FALSE,
  WAIC = TRUE)

# calcul du WAIC
waic.full <- mcmc.output$WAIC$WAIC
waic.null <- mcmc.null$WAIC$WAIC

# affichage comparatif
tibble(
  Modèle = c("Avec température", "Sans température"),
  WAIC = c(waic.full,
           waic.null)
)

#' #### Ajustement du modèle en fréquentiste avec `lme4`

library(lme4)

fit_lme4 <- glmer(
  Ragondins ~ Temp + (1 | Transect), # formule complète
  data   = sim_simple,        # jeu de données simulé précédemment
  family = poisson      # distribution adaptée à un comptage
)

summary(fit_lme4)

#' ## En résumé
