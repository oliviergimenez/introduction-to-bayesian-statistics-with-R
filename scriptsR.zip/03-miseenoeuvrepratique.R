#' # Mise en oeuvre pratique

#' ## Introduction

#' ## `NIMBLE`

library(nimble)
library(tidyverse)


model <- nimbleCode({
  # vraisemblance
  y ~ dbinom(theta, n)
  # prior
  theta ~ dbeta(1, 1) # ou dunif(0,1)
})

model

dat <- list(n = 57, y = 19)

par <- c("theta")

init1 <- list(theta = 0.1) # chaîne 1
init2 <- list(theta = 0.5) # chaîne 2
init3 <- list(theta = 0.9) # chaîne 3
inits <- list(init1, init2, init3) # une liste de listes
inits

inits <- function() list(theta = runif(1,0,1))
inits()

n.iter <- 2000
n.burnin <- 300
n.chains <- 3

mcmc.output <- nimbleMCMC(code = model, # modèle
                          data = dat, # données
                          inits = inits, # valeurs initiales
                          monitors = par, # paramètres que l'on souhaite en sortie
                          niter = n.iter, # nombre total d'itérations
                          nburnin = n.burnin, # nombre d'itération du burn-in
                          nchains = n.chains) # nombre de chaînes

str(mcmc.output)

dim(mcmc.output$chain1)
head(mcmc.output$chain1)

mean(mcmc.output$chain1[,"theta"])

quantile(mcmc.output$chain1[,"theta"], probs = c(2.5, 97.5)/100)

## Histogramme de la distribution a posteriori de la probabilité de survie theta
mcmc.output$chain1[,"theta"] %>%
  as_tibble() %>%
  ggplot() +
  geom_histogram(aes(x = value), color = "white") +
  labs(x = "Probabilité de survie")

library(MCMCvis)

MCMCsummary(object = mcmc.output, round = 2)

## Caterpillar plot de la distribution a posteriori de la probabilité de survie theta
MCMCplot(object = mcmc.output, params = 'theta')

## Trace plot et densité a posteriori de la probabilité de survie theta
MCMCtrace(object = mcmc.output,
          pdf = FALSE, # ne pas exporter en PDF
          ind = TRUE,  # une courbe par chaîne
          params = "theta")

## Trace plot et densité a posteriori de la probabilité de survie theta 
## avec les diagnostics de convergence
MCMCtrace(object = mcmc.output,
          pdf = FALSE,
          ind = TRUE,
          Rhat = TRUE, # ajoute le Rhat
          n.eff = TRUE, # ajoute la taille d’échantillon effective
          params = "theta")

theta_samples <- c(mcmc.output$chain1[,"theta"],
                   mcmc.output$chain2[,"theta"],
                   mcmc.output$chain3[,"theta"])

lambda <- -1/log(theta_samples)

head(lambda)

mean(lambda)
quantile(lambda, probs = c(2.5, 97.5)/100)

## Histogramme de la distribution a posteriori de l'espérance de vie.
lambda %>%
  as_tibble() %>%
  ggplot() +
  geom_histogram(aes(x = value), color = "white") +
  labs(x = "Espérance de vie")

#' ## `brms`

dat <- data.frame(y = 19, n = 57)

library(brms)

bayes.brms <- brm(y | trials(n) ~ 1,
                  family = binomial("logit"),
                  data = dat,
                  chains = 3,
                  iter = 2000,
                  warmup = 300,
                  thin = 1,
                  refresh = 0)

summary(bayes.brms)

library(posterior)
draws_fit <- as_draws_matrix(bayes.brms)

beta <- draws_fit[,'Intercept'] # sélectionne la colonne intercept
theta <- plogis(beta)  # conversion logit -> [0,1]

mean(theta)
quantile(theta, probas = c(2.5,97.5)/100)

summarise_draws(theta)

## Histogramme de la distribution a posteriori de la probabilité de survie theta.
draws_fit %>%
  ggplot(aes(x = theta)) +
  geom_histogram(color = "white", fill = "steelblue", bins = 30) +
  labs(x = "Probabilité de survie", y = "Fréquence")

## Histogramme de la distribution a posteriori et trace plot de la 
## probabilité de survie sur l’échelle logit (b). Dans l’histogramme, l’axe 
## des abscisses représente les valeurs possibles de l’intercept (échelle 
## logit) et l’axe des ordonnées la fréquence des valeurs simulées. Dans 
## le trace plot, l’axe des abscisses correspond au numéro de l’itération 
## MCMC et l’axe des ordonnées aux valeurs simulées de l’intercept (échelle 
## logit).
plot(bayes.brms)

beta <- draws_fit[,'Intercept'] # sélectionne la colonne intercept
theta <- plogis(beta)  # conversion logit -> [0,1]
lambda <- -1 / log(theta) # transforme survie en espérance de vie
summarize_draws(lambda) # résumé des tirages : moyenne, médiane, intervalles

## Histogramme de la distribution a posteriori de l'espérance de vie. 
## L'axe des abscisses représente les différentes valeurs possibles de 
## l'espérance de vie. L'axe vertical indique le nombre de tirages simulés 
## (Count) pour chaque valeur.
lambda %>%
  as_tibble() %>%
  ggplot() +
  geom_histogram(aes(x = Intercept), color = "white") +
  labs(x = "Espérance de vie")

prior_summary(bayes.brms)

nlprior <- prior(normal(0, 1.5), class = "Intercept")

bayes.brms <- brm(y | trials(n) ~ 1,
                  family = binomial("logit"),
                  data = dat,
                  prior = nlprior, 
                  chains = 3,
                  iter = 2000,
                  warmup = 300,
                  thin = 1,
                  refresh = 0)

summary(bayes.brms)

#' ## En résumé
