#' # L'approche bayésienne
#' 
#' ## Introduction
#' 
#' ## Le théorème de Bayes
#' 
#' ## Qu'est-ce que la statistique bayésienne ?
#' 
#' ## Un exemple fil rouge
#' 
## ------------------------------------------------------------------
y <- 19 # nombre d'individus ayant survécu à l'hiver
n <- 57 # nombre d'individus suivis au début de l'hiver

## Distributions de probabilité discrètes, Bernoulli et binomiale, 
## illustrées avec 100 simulations (des tirages aléatoires générés par 
## ordinateur). On représente sur la ligne du haut la fréquence observée 
## d'un tirage Bernoulli pour différentes valeurs de probabilité de survie 
## theta. Sur la ligne du bas, on a les histogrammes pour un tirage 
## binomial avec 50 tentatives et différentes valeurs de probabilité de survie 
## theta.

library(tidyverse)
library(patchwork)
set.seed(123) # reproductibilité

theme_clean <- theme(
  axis.title = element_blank()
)

# --- Bernoulli theta = 0.5 ---
b1 <- rbinom(100,1,0.5) %>%
  as_tibble() %>%
  mutate(etat = fct_recode(as_factor(value), "mort" = "0", "vivant" = "1")) %>%
  count(etat) %>%
  ggplot(aes(x = etat, y = n)) +
  geom_col(fill = "#009E73", color = "black") +
  labs(title = expression("Bernoulli " * theta * " = 0.5", x = NULL, y = NULL)) +
  theme_clean

# --- Bernoulli theta = 0.2 ---
b2 <- rbinom(100,1,0.2) %>%
  as_tibble() %>%
  mutate(etat = fct_recode(as_factor(value), "mort" = "0", "vivant" = "1")) %>%
  count(etat) %>%
  ggplot(aes(x = etat, y = n)) +
  geom_col(fill = "#009E73", color = "black") +
  labs(title = expression("Bernoulli " * theta * " = 0.2", x = NULL, y = NULL)) +
  theme_clean

# --- Bernoulli theta = 0.8 ---
b3 <- rbinom(100,1,0.8) %>%
  as_tibble() %>%
  mutate(etat = fct_recode(as_factor(value), "mort" = "0", "vivant" = "1")) %>%
  count(etat) %>%
  ggplot(aes(x = etat, y = n)) +
  geom_col(fill = "#009E73", color = "black") +
  labs(title = expression("Bernoulli " * theta * " = 0.8", x = NULL, y = NULL)) +
  theme_clean

# --- Binomiale N = 50, theta = 0.5 ---
bin1 <- rbinom(100,50,0.5) %>%
  as_tibble() %>%
  count(value) %>%
  ggplot(aes(x = value, y = n)) +
  geom_col(fill = "#E69F00", color = "black") +
  labs(title = expression("Binomiale avec n = 50 et " * theta * " = 0.5"), x = "nombre de survivants", y = NULL) 

# --- Binomiale N = 50, theta = 0.2 ---
bin2 <- rbinom(100,50,0.2) %>%
  as_tibble() %>%
  count(value) %>%
  ggplot(aes(x = value, y = n)) +
  geom_col(fill = "#E69F00", color = "black") +
  labs(title = expression("Binomiale avec n = 50 et " * theta * " = 0.2"), x = "nombre de survivants", y = NULL) 

# --- Binomiale N = 50, theta = 0.8 ---
bin3 <- rbinom(100,50,0.8) %>%
  as_tibble() %>%
  count(value) %>%
  ggplot(aes(x = value, y = n)) +
  geom_col(fill = "#E69F00", color = "black") +
  labs(title = expression("Binomiale avec n = 50 et " * theta * " = 0.8"), x = "nombre de survivants", y = NULL) 

# --- Combinaison avec patchwork ---
(b1 + b2 + b3) / (bin1 + bin2 + bin3)

#' ## Le maximum de vraisemblance

dbinom(x = 0, size = 57, prob = 1 - 0.5)

## Fonction de vraisemblance pour la probabilité de survie hivernale du 
## ragondin, calculée à partir de $y=19$ survivants sur $n=57$ individus 
## suivis par GPS. Le maximum de vraisemblance est indiqué par le pointillé 
## rouge.
y <- 19
n <- 57
grille <- seq(0, 1, 0.01)
vraisemblance <- dbinom(y, n, grille)
theta_mle <- y / n

df <- data.frame(survie = grille, vraisemblance = vraisemblance)

df %>%
  ggplot() +
  aes(x = survie, y = vraisemblance) +
  geom_line(linewidth = 1.5) +
  geom_vline(xintercept = theta_mle, linetype = "dashed", color = "red") +
  labs(x = expression("Probabilité de survie (" * theta * ")"),
       y = "vraisemblance") +
  theme_minimal()

mod <- glm(cbind(y, n - y) ~ 1, family = binomial)
theta_hat <- plogis(coef(mod))
theta_hat

#' ## Et en bayésien?
#' 
## Exemples de lois bêta pour différentes valeurs des paramètres $a$ et $b$. 
## Dans chaque panneau, les zones ombrées illustrent la probabilité d'observer 
## une valeur dans un intervalle donné.

x <- seq(0, 1, length.out = 200)
ordre <- c("Beta(1,1)", "Beta(2,1)", "Beta(1,2)", "Beta(2,2)", "Beta(10,10)", "Beta(0.8,0.8)")

# Générer les valeurs de densité
df <- data.frame(
  x = rep(x, 6),
  y = c(dbeta(x, 1, 1), dbeta(x, 2, 1), dbeta(x, 1, 2),
        dbeta(x, 2, 2), dbeta(x, 10, 10), dbeta(x, 0.8, 0.8)),
  distribution = factor(rep(ordre, each = length(x)), levels = ordre)
)

# Zones ombrées
zone1 <- df %>%
  filter(distribution == "Beta(1,1)") %>%
  filter((x >= 0.1 & x <= 0.2))

zone2 <- df %>%
  filter(distribution == "Beta(1,1)") %>%
  filter((x >= 0.8 & x <= 0.9))

zone3 <- df %>%
  filter(distribution == "Beta(2,1)") %>%
  filter((x >= 0.1 & x <= 0.2))

zone4 <- df %>%
  filter(distribution == "Beta(2,1)") %>%
  filter((x >= 0.8 & x <= 0.9))

zone5 <- df %>%
  filter(distribution == "Beta(1,2)") %>%
  filter((x >= 0.1 & x <= 0.2))

zone6 <- df %>%
  filter(distribution == "Beta(1,2)") %>%
  filter((x >= 0.8 & x <= 0.9))

zone7 <- df %>%
  filter(distribution == "Beta(2,2)") %>%
  filter((x >= 0.1 & x <= 0.2))

zone8 <- df %>%
  filter(distribution == "Beta(2,2)") %>%
  filter((x >= 0.5 & x <= 0.6))

zone9 <- df %>%
  filter(distribution == "Beta(10,10)") %>%
  filter((x >= 0.2 & x <= 0.3))

zone10 <- df %>%
  filter(distribution == "Beta(10,10)") %>%
  filter((x >= 0.5 & x <= 0.6))

zone11 <- df %>%
  filter(distribution == "Beta(0.8,0.8)") %>%
  filter((x >= 0 & x <= 0.1))

zone12 <- df %>%
  filter(distribution == "Beta(0.8,0.8)") %>%
  filter((x >= 0.9 & x <= 1))

zone13 <- df %>%
  filter(distribution == "Beta(0.8,0.8)") %>%
  filter((x >= 0.45 & x <= 0.55))

# Tracé final
df %>%
  ggplot(aes(x = x, y = y)) +
  geom_line(color = "red", size = 1.2) +
  geom_area(data = zone1, fill = "red", alpha = 0.2) +
  geom_area(data = zone2, fill = "red", alpha = 0.2) +
  geom_area(data = zone3, fill = "red", alpha = 0.2) +
  geom_area(data = zone4, fill = "red", alpha = 0.2) +
  geom_area(data = zone5, fill = "red", alpha = 0.2) +
  geom_area(data = zone6, fill = "red", alpha = 0.2) +
  geom_area(data = zone7, fill = "red", alpha = 0.2) +
  geom_area(data = zone8, fill = "red", alpha = 0.2) +
  geom_area(data = zone9, fill = "red", alpha = 0.2) +
  geom_area(data = zone10, fill = "red", alpha = 0.2) +
  geom_area(data = zone11, fill = "red", alpha = 0.2) +
  geom_area(data = zone12, fill = "red", alpha = 0.2) +
  geom_area(data = zone13, fill = "red", alpha = 0.2) +
  facet_wrap(~ distribution, scales = "free_y") +
  labs(x = expression(theta), y = "Densité") +
  theme_minimal()

## Distribution a priori uniforme (rouge) et distribution a posteriori (noire) 
## de la probabilité de survie hivernale du ragondin. Le pointillé bleu correspond 
## à l'estimateur du maximum de vraisemblance.
df_post <- data.frame(
  theta = x,
  prior = dbeta(x, 1, 1),
  posterior = dbeta(x, 20, 39)
)

df_post %>%
  ggplot(aes(x = theta)) +
  geom_line(aes(y = prior), color = "red", size = 1.2) +
  geom_line(aes(y = posterior), color = "black", size = 1.2) +
  geom_vline(xintercept = 19/57, linetype = "dashed", color = "blue", size = 1) +
  labs(x = expression("Probabilité de survie (" * theta * ")"), y = "Densité") +
  theme_minimal()

#' ## En résumé

